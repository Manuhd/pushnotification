<?php
/*
Plugin Name: Push Notification Plugin
Description: A plugin to send push notifications using OneSignal.
Version: 1.0
Author URI: https://www.linkedin.com/in/manu-hd-a07090158/
Author: Manu HD
*/

// Create form for admin panel
function push_notification_form() {
    ?>
    <div class="wrap">
        <h2>Send Push Notification</h2>
        <form id="push_notification_form" method="post" action="<?php echo admin_url('admin-post.php'); ?>">
            <input type="hidden" name="action" value="send_notification">
            <label for="notification_title">Title:</label><br>
            <input type="text" id="notification_title" name="notification_title" cols="50" style="width: 100%; max-width: 500px;"><br><br>

            <label for="notification_message">Message:</label><br>
            <textarea id="notification_message" name="notification_message" cols="50" style="width: 100%; max-width: 500px;"></textarea><br><br>
<label for="notification_image" >Image URL:</label><br>
            <input type="url" id="notification_image" name="notification_image" cols="50" style="width: 100%; max-width: 500px;"><br><br>


          <!--<label for="notification_url">Target URL:</label><br>
            <input type="url" id="notification_url" name="notification_url" cols="50" style="width: 100%; max-width: 500px;"><br><br>-->

            <input type="submit" value="Send Notification" style="background-color: #4CAF50; /* Green */
                                                    border: none;
                                                    color: white;                                                
                                                    padding: 15px 32px;
                                                    text-align: center;
                                                    text-decoration: none;
                                                    display: inline-block;
                                                    font-size: 16px;
                                                    margin: 15px 2px;
                                                    cursor: pointer;
                                                    border-radius: 10px;">
        </form>
    </div>
<!--<script>
        jQuery(document).ready(function($) {
            $('#push_notification_form').on('submit', function(event) {
                var title = $('#notification_title').val();
                var subtitle = $('#notification_message').val();
                var imageUrl = $('#notification_image').val();

                if (!title && !subtitle && !imageUrl) {
                    alert('At least one field should be filled');
                    event.preventDefault();
                }
            });
        });
    </script>-->
    <?php
}

// Handle form submission
function send_push_notification() {
    if (isset($_POST['action']) && $_POST['action'] === 'send_notification') {
        $title = $_POST['notification_title'];
        $message = $_POST['notification_message'];
         $image_url = $_POST['notification_image'];
          // Include current date and time in the message
        $message .= "\n\nCurrent Date and Time: " . date('Y-m-d H:i:s');
       // $url = $_POST['notification_url'];

        // Use OneSignal API to send the push notification
        // Replace 'YOUR_ONESIGNAL_APP_ID' and 'YOUR_ONESIGNAL_REST_API_KEY' with your actual OneSignal App ID and REST API Key
        $onesignal_app_id = 'b3eccc1b-fa2e-43ba-bedc-eed99c1947d2';
        $onesignal_rest_api_key = 'ZjViZDkzMzItMTY2MC00NjAzLTljN2YtYjE3Y2ZlYTJlMmNk';

        $fields = array(
            'app_id' => $onesignal_app_id,
            'included_segments' => array('All'),
            'contents' => array('en' => $message),
            'headings' => array('en' => $title),
            'big_picture' => $image_url
           // 'send_after' => date('Y-m-d H:i:s', strtotime($datetime)) // Convert to OneSignal datetime format
        );
    // Add image URL if provided
    //     if (!empty($image_url)) {
    //       $fields['big_picture'] = $image_url;
    //   }

        $fields = json_encode($fields);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, "https://onesignal.com/api/v1/notifications");
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json', 'Authorization: Basic ' . $onesignal_rest_api_key));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
        $response = curl_exec($ch);
        curl_close($ch);

        // Handle response if needed
        if ($response) {
            echo "Push notification sent successfully!";
        } else {
            echo "Failed to send push notification.";
        }
    }
}

// Hook functions
add_action('admin_menu', 'push_notification_menu');
function push_notification_menu() {
    add_menu_page('Push Notification', 'Push Notification', 'manage_options', 'push_notification', 'push_notification_form');
}

add_action('admin_post_send_notification', 'send_push_notification');
